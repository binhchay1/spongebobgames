                <!--<article>-->
                <section class="blkcnt bgco2 game-info">
                    <header class="bltitl"><h2><?php the_title(); ?></h2></header>
                    <section class="blcnbx">
						<?php the_content(); ?>
                    </section>
                </section>
                <!--</article>-->